<?php
include 'funtion.php';


if (isset ($_POST["cari"])) {
   $pencarian = $_POST ["pencarian"];
$cari_db = "SELECT*FROM daftar_barang 
    WHERE
    nama_barang like '%$pencarian%' or
    harga like '%$pencarian%'
    ";
   $cari =mysqli_query($conn, $cari_db);
}else {
    $cari = mysqli_query($conn,"SELECT*FROM daftar_barang");

}
?>
<!doctype html>
<html>
    <head><title>Data Barang</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="gambar.png" alt="ini gambar budaya Indonesia">
          </div>
          <div class="header-title">
              <a href="data-barang.php">DATA BARANG TOKO KITO SMKN 6 KOTA JAMBI</a>
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
          </ul>
          <div class="konten">
             <h1>Data Barang</h1>
<br>
<div class="input">
             <form action="" method="post">
             <input type="text" name ="pencarian" placeholder="ketik pencarian Anda" autofocus autocomplete="off" size=""50px>
             <button type="submit" name ="cari">Cari Data</button>
             </br>
             <br>
          </form>
</div>
              <table class="tabel">
                <tr class="tabel-header">
                    <th>No</th>
                    <th>NAMA BARANG</th>
                    <th>STOK BARANG</th>
                    <th>HARGA</th>
                    <th>SETTING</th>
                </tr>
                <?php 
                $nomor=1;
                ?>
            <?php while($data=mysqli_fetch_assoc($cari)):
            ?>
                <tr class="tabel-konten">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data ["nama_barang"];?></td>
                    <td><?php echo $data ["stok_barang"];?></td>
                    <td><?php echo $data ["harga"];?></td>
                    <td>
                        <a href="edit-barang.php?no=<?=  $data ["no"]; ?> ">Edit|</a>
                        <a href="hapus-barang.php?no=<?=  $data ["no"]; ?> "onclick = "return confirm ('Apakah anda yakin?')">Hapus</a>
                    </td>
                </tr>
                <?php
                $nomor ++;
                ?>
                <?php
                endwhile;
                ?>
</table>
          </div>
          <div class="fotter">
          <p>JUWITA SALMAH XII PPLG 1(PPLG01-0081)</p>
          </div>
    </body>
</html>