<?php
include('funtion.php');

$no= $_GET["no"];

if ( hapus ($no)>0){

    header ("Location: data-barang.php");
    exit;

}


?>