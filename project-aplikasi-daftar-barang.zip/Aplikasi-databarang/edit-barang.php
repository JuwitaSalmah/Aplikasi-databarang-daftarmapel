<?php
include('funtion.php');

$no=$_GET["no"];
$cari= mysqli_query ($conn,"SELECT*FROM daftar_barang WHERE no='$no'");
if(isset($_POST["submit"])){
   
    // var_dump($_POST);
if (edit($_POST)>0){
    
    echo "<script>
    alert ('DATA BERHASIL DIEDIT');
    document.location.href='data-barang.php';
    </script>
    ";

}else{
    echo "<script>
    alert ('DATA GAGAL DIEDIT');
    document.location.href='data-barang.php';
    </script>
    ";
}

}

?>
<!doctype html>
<html>
    <head><title>Data Barang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
    <div class="header">
    <div class="header-logo">
    <img src="gambar.png" alt="logo1">
    </div>
    <div class="header-title">
        <a href="index.php">DATA BARANG TOKO KITO SMKN 6 KOTA JAMBI</a>
    </div>
    </div>
    <ul class="menu">
        <li class="menu-item"> <a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"> <a href="tambah-barang.php">Tambah Barang</a></li>
    </ul>
    <div class="konten">
       <h1>Edit barang</h1>
       <?php
       while($data=mysqli_fetch_assoc ($cari)):
       ?>
       <form action=""method="POST">
       <label for="">No</label>
       <input type="text"name="no" VALUE="<?php echo $data ["no"]; ?>">
        <br>
        <br>
       <label for="">Nama Barang</label>
       <input type="text"name="nama_barang" required VALUE="<?php echo $data ["nama_barang"]; ?>">
       <br>
       <br>
       <label for="">Stok Barang</label>
       <input type="text"name="stok_barang" required VALUE="<?php echo $data ["stok_barang"]; ?>">
       <br>
       <br>
       <label for="">Harga</label>
       <input type="text"name="harga" required VALUE="<?php echo $data ["harga"]; ?>">
       <br>
       <br>
       <button type="submit" name="submit">tambahkan</button>
       <?php
       endwhile;
       ?>
       </form>
       </div>

       <div class="fotter">
       <p>JUWITA SALMAH XII PPLG 1(PPLG01-0081)</p>
        </div>

</body>
</html>