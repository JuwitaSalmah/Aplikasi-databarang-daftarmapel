<?php
include('funtion.php');
if(isset($_POST["submit"])){
    // var_dump($_POST);
    //var_dump(mysqli_affected_rows ($conn));
    if(tambah ($_POST) >0){
        echo "<script>
    alert ('DATA BERHASIL DITAMBAHKAN');
    document.location.href='data-barang.php';
    </script>
    ";

}else{
    echo "<script>
    alert ('DATA GAGAL DITAMBAHKAN');
    document.location.href='data-barang.php';
    </script>
    ";
}
}
    
?>
<!doctype html>
<html>
    <head><title>Data Barang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
    <div class="header">
    <div class="header-logo">
    <img src="gambar.png">
    </div>
    <div class="header-title">
        <a href="index.php">DATA BARANG TOKO KITO SMKN 6 KOTA JAMBI</a>
    </div>
    </div>
    <ul class="menu">
        <li class="menu-item"> <a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"> <a href="tambah-barang.php">Tambah Barang</a></li>
</ul>
    <div class="konten">
       <h2>Tambah Barang</h2>
       <form action=""method="POST">
        <br>
       <label for="">No</label>
       <input type="text"name="no" required>
       <br>
       <br>
       <label for="">Nama Barang</label>
       <input type="text"name="nama_barang" required>
       <br>
       <br>
       <label for="">Stok Barang</label>
       <input type="text"name="stok_barang" required>
       <br>
       <br>
       <label for="">harga</label>
       <input type="text"name="harga" required>
       <br>
       <br>
       <button type="submit" name="submit">tambahkan</button>
       </form>
       </div>

       <div class="fotter">
       <p>JUWITA SALMAH XII PPLG 1(PPLG01-0081)</p>
        </div>

</body>
</html>