<?php
$conn= mysqli_connect ("localhost","root","","databarang");
function tambah($no) {
    global $conn;
    $no =htmlspecialchars($_POST ["no"]);
    $nama =htmlspecialchars($_POST ["nama_barang"]);
    $stok =htmlspecialchars ($_POST ["stok_barang"]);
    $harga =htmlspecialchars($_POST ["harga"]);

    $query= "INSERT INTO daftar_barang VALUES ('$no','$nama', '$stok', '$harga')";
    mysqli_query ($conn, $query);

    return mysqli_affected_rows ($conn);

}
function edit ($no){
global $conn;
$no=htmlspecialchars($_POST ["no"]);
$nama =htmlspecialchars($_POST ["nama_barang"]);
$stok =htmlspecialchars ($_POST ["stok_barang"]);
$harga =htmlspecialchars($_POST ["harga"]);

//$query= "INSERT INTO buku VALUES ('$kode_buku', '$gambar', '$judul', '$penerbit')";
$query="UPDATE daftar_barang SET
        no='$no',
        nama_barang='$nama',
        stok_barang='$stok',
        harga='$harga'
        WHERE no=$no";
mysqli_query ($conn, $query);
return mysqli_affected_rows ($conn);

}

function hapus ($no){
global $conn;
mysqli_query ($conn,"DELETE FROM daftar_barang WHERE no=$no");
return mysqli_affected_rows ($conn);

}