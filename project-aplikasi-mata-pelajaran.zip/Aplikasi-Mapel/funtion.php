<?php
$conn = mysqli_connect ('localhost', 'root', '', 'daftar_pelajaran');

function tambah_mapel ($cari) {
    global $conn;
    $hari =  htmlspecialchars($_POST["hari"]);
    $jam =  htmlspecialchars($_POST["jamke"]);
    $waktu =  htmlspecialchars($_POST["waktu"]);
    $kelas =  htmlspecialchars($_POST["kelas"]);
    $pelajaran =  htmlspecialchars($_POST["pelajaran"]);
    $kode =  htmlspecialchars($_POST["kodeguru"]);
    
    $cari="INSERT INTO pelajaran
    VALUES ('','$hari', '$jam' , '$waktu' , '$kelas', '$pelajaran' , '$kode' )
    ";
    mysqli_query ($conn, $cari);

    return mysqli_affected_rows ($conn); }

function edit_mapel ($cari) {
    global $conn;
    $id =  htmlspecialchars($_POST["id"]);
    $hari =  htmlspecialchars($_POST["hari"]);
    $jam =  htmlspecialchars($_POST["jamke"]);
    $waktu =  htmlspecialchars($_POST["waktu"]);
    $kelas =  htmlspecialchars($_POST["kelas"]);
    $pelajaran =  htmlspecialchars($_POST["pelajaran"]);
    $kode =  htmlspecialchars($_POST["kodeguru"]);

    //$query= "INSERT INTO barang VALUES ('','$stok_barang',  '$gambar', '$judul', '$penerbit')";
    $cari="UPDATE pelajaran SET
            id ='$id',
            hari ='$hari',
            jamke='$jam',
            waktu ='$waktu',
            kelas='$kelas',
            pelajaran ='$pelajaran',
            kodeguru ='$kode'
            WHERE id=$id";
mysqli_query ($conn, $cari);
return mysqli_affected_rows ($conn);
}

function hapus_mapel ($id){
    global $conn;
    mysqli_query ($conn, "DELETE FROM pelajaran WHERE id = $id");
    return mysqli_affected_rows ($conn);

}

?>