<?php
include 'funtion.php';

if(isset($_POST["cari"])) {
   $pencarian=$_POST ["pencarian"];
   $cari_dm= "SELECT*FROM pelajaran
    WHERE
    id like'%$pencarian%' or
    hari like'%$pencarian%' or
    jamke like'%$pencarian%' or
    waktu like'%$pencarian%' or
    kelas like'%$pencarian%' or
    pelajaran like'%$pencarian%' or
    kodeguru like'%$pencarian%'
    ";
    $cari=mysqli_query($conn, $cari_dm);
}else{
    $cari=mysqli_query($conn,"SELECT*FROM pelajaran");

}
?>
<!doctype html>
<html>
    <head><title>Aplikasi Daftar Mata Pelajaran PPLG UKK SMKN 6 Kota Jambi</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
          <div class="header-logo">
          <img src="logosmkn6.jpg" alt="Gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Aplikasi Daftar Mata Pelajaran PPLG UKK SMKN 6 Kota Jambi</a>
          </div>
          </div>
          <ul class="menu">
              <li class="menu-item"><a href="daftar-mapel.php">Daftar Mapel</a></li>
              <li class="menu-item"><a href="tambah-mapel.php">Tambah Mapel</a></li>
             
          </ul>
          <div class="konten">
             <h1>Daftar Mata Pelajaran PPLG</h1>
             <div class="input">
             <form action="" method="post">
             <br>
             <input type="text" name="pencarian" placeholder="Ketik Pencarian Anda" autofocus autocomplete="off" size=""50px>
             <button type="submit" name="cari">Cari Mapel</button>
</form>
</div>
<br>
              <table class="tabel">
                <tr class="tabel-header">
                    <th>Hari</th>
                    <th>Jam Ke</th>
                    <th>Waktu</th>
                    <th>Kelas</th>
                    <th>Pelajaran</th>
                    <th>Kode Guru</th>
                    <th>Seting</th>
                </tr>
                <?php 
                $nomor=1;
                ?>
            <?php while($data=mysqli_fetch_assoc($cari)):
            ?>

                <tr class="tabel-konten">
                    <td><?php echo $data ["hari"];?></td>
                    <td><?php echo $data ["jamke"];?></td>
                    <td><?php echo $data ["waktu"];?></td>
                    <td><?php echo $data ["kelas"];?></td>
                    <td><?php echo $data ["pelajaran"];?></td>
                    <td><?php echo $data ["kodeguru"];?></td>
                    
                    <td>
                        <a href="edit.php?id=<?=  $data ["id"]; ?> ">Edit</a> |
                        <a href="hapus.php?id=<?=  $data ["id"]; ?> "onclick = "return confirm ('Apakah anda yakin?')">Hapus</a>
                    </td>
                </tr>
                <?php
                $nomor ++;
                ?>
                <?php
                endwhile;
                ?>
</table>
          </div>
          <div class="fotter">
            <p>JUWITA SALMAH XII PPLG 1(PPLG01-0081)
            </p>
          </div>
    </body>
</html>