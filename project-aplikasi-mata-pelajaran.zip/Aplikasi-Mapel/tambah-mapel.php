<?php
include 'funtion.php';

//Cek apakah $_post submit sudah di tekan atau belum
if(isset($_POST["submit"])){
//var_dump($_POST); //ada tidak data yang ada di $_POST nya
//ambil data dari tiap element dalam form

         if(tambah_mapel ($_POST) >0){
           
                echo "<script>
                alert ('Data Berhasil ditambahkan');
                document.location.href='daftar-mapel.php';
                </script>
                ";
                
            } else {
                echo "<script>
                alert ('Data Gagal ditambahkan');
                document.location.href='daftar-mapel.php';
                </script>
                ";   
                
            }
         }
       
       

        //Query Insert Data
       
        
        //untuk mengecek apakah data brhasil di tambahkan atau tidak
        var_dump(mysqli_affected_rows($conn));
       
        

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Mapel</title><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
        <div class="header-logo">
            <img src="logosmkn6.jpg" alt="Gambar Logo" >
        </div>
        <div class="header-title">
            <a href="index.php"> Aplikasi Daftar Pelajaran UKK SMKN 6 Kota Jambi</a>
        </div>
    </div>
	<ul class="menu">
        <li class="menu-item"><a href="daftar-mapel.php">Daftar Mapel</a></li>
        <li class="menu-item"><a href="tambah-mapel.php">Tambah Mapel</a></li>
    </ul>
    <h2>Tambah Mapel</h2>
    <form action="" method="post">
    <label for="">Hari</label>
        <input type="text" name="hari" id="hari" required>
        <br>
        <br>
        <label for="">Jam Ke</label>
        <input type="text" name="jamke" id="jamke" required>
        <br>
        <br>
        <label for="">Waktu</label>
        <input type="time" name="waktu" id="waktu" required>
        <br>
        <br>
        <label for="">Kelas</label>
        <input type="text"  name="kelas" id="kelas"  required>
        <br>
        <br>
        <label for="">Pelajaran</label>
        <input type="text"  name="pelajaran" id="pelajaran"  required>
        <br>
        <br>
        <label for="">Kode Guru</label>
        <input type="text"  name="kodeguru" id="kodeguru"  required>
        <br>
        <br>
        <button type="submit" name="submit">Tambahkan Data</button>
    </form>
    <div class="fotter">
        <P>JUWITA SALMAH XII PPLG 1(PPLG01-0081)</P> 
 
     </div>    
</body>
</html>